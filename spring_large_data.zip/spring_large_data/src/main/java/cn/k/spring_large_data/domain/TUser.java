package cn.k.spring_large_data.domain;

import cn.k.spring_large_data.anno.DecryptField;
import cn.k.spring_large_data.anno.EncryptField;

/**
 * @decription TUser
 * <p>用户pojo</p>
 * @author Yampery
 * @date 2018/4/4 14:00
 */
public class TUser {
    private Integer id;

    private String userName;

    @EncryptField
    @DecryptField
    private String phone;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    @Override
    public String toString() {
        return "TUser{" +
                "userName='" + userName + '\'' +
                ", phone='" + phone + '\'' +
                '}';
    }
}