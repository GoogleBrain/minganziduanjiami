package cn.k.spring_large_data.controller;

import cn.k.spring_large_data.domain.TUser;
import cn.k.spring_large_data.service.UserService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import javax.websocket.server.PathParam;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@Slf4j
public class JiaJieController {

    @Resource
    private UserService userService;

    @RequestMapping(value = "/insert", method = RequestMethod.GET)
    public Integer insert() throws Exception {
        TUser user = new TUser();
        user.setPhone("17600313199");
        user.setUserName("huzaibin");
        userService.insert(user);
        return 1;
    }

    @RequestMapping(value = "/select/{id}", method = RequestMethod.GET)
    public List<TUser> select(@PathVariable("id") Integer id) throws Exception {
        Map<String,Object> map = new HashMap<String,Object>();
        map.put("id",id);
        return userService.queryList(map);
    }
}